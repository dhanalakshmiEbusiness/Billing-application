var dataSeederUsingMongo = require('./lib/dataSeederUsingMongo').seeder;
module.exports={
    dataSeederUsingMongo:dataSeederUsingMongo
}